import tkinter as tk
from tkinter import messagebox

class TaskManager:
    def __init__(self, root):
        self.root = root
        self.root.title("Task Manager")

        # Task list
        self.tasks = []

        # Task entry
        self.task_entry = tk.Entry(root, width=30)
        self.task_entry.grid(row=0, column=0, padx=10, pady=10)

        # Add task button
        add_button = tk.Button(root, text="Add Task", command=self.add_task)
        add_button.grid(row=0, column=1, padx=10, pady=10)

        # Task listbox
        self.task_listbox = tk.Listbox(root, width=40, height=10)
        self.task_listbox.grid(row=1, column=0, columnspan=2, padx=10, pady=10)

        # Mark as completed button
        mark_completed_button = tk.Button(root, text="Mark as Completed", command=self.mark_completed)
        mark_completed_button.grid(row=2, column=0, padx=10, pady=10)

        # Delete task button
        delete_button = tk.Button(root, text="Delete Task", command=self.delete_task)
        delete_button.grid(row=2, column=1, padx=10, pady=10)

    def add_task(self):
        task_text = self.task_entry.get()
        if task_text:
            self.tasks.append(task_text)
            self.update_task_list()
            self.task_entry.delete(0, tk.END)  # Clear the entry

    def update_task_list(self):
        self.task_listbox.delete(0, tk.END)  # Clear the listbox
        for task in self.tasks:
            self.task_listbox.insert(tk.END, task)

    def mark_completed(self):
        selected_task_index = self.task_listbox.curselection()
        if selected_task_index:
            task_index = selected_task_index[0]
            if task_index < len(self.tasks):
                completed_task = self.tasks.pop(task_index)
                messagebox.showinfo("Task Completed", f"{completed_task} marked as completed.")
                self.update_task_list()

    def delete_task(self):
        selected_task_index = self.task_listbox.curselection()
        if selected_task_index:
            task_index = selected_task_index[0]
            if task_index < len(self.tasks):
                deleted_task = self.tasks.pop(task_index)
                messagebox.showinfo("Task Deleted", f"{deleted_task} deleted.")
                self.update_task_list()

if __name__ == "__main__":
    root = tk.Tk()
    app = TaskManager(root)
    root.mainloop()
